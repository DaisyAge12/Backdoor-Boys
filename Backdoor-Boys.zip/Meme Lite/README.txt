Import/Update Meme Lite r2z file
Replace default config folder with new config folder
To find config folder:
Open r2modman
select Meme Lite profile
Go to settings
Locations
Browse profile folder
Open BepinEx