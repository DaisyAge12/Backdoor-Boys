Import/Update Mimics and Skinwalkers r2z file
Replace default config folder with new config folder
To find config folder:
Open r2modman
select Mimics and Skinwalker profile
Go to settings
Locations
Browse profile folder
Open BepinEx