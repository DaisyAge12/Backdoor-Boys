Import/Update Memes r2z file
Replace default config folder with new config folder
To find config folder:
Open r2modman
select Memes profile
Go to settings
Locations
Browse profile folder
Open BepinEx