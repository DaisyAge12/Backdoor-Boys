Import/Update All Mods r2z file
Replace default config folder with new config folder
To find config folder:
Open r2modman
select All Mods profile
Go to settings
Locations
Browse profile folder
Open BepinEx